
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public int lives = 3;

    public void LoseLife()
    {
        lives--;
        if (lives <= 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
}
